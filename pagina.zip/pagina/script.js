function cambiarEstado () {
    let elemento = document.getElementById('audioMision')
    elemento.play*(SimbaAudio.mp3)
}